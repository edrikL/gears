// Copyright 2007 Google Inc. All Rights Reserved.
//
// Sets up google.gears.factory to point to an instance of GearsFactory.
//
// google.gears.factory is *the only* supported way to access GearsFactory.
// We reserve the right to change the way Google Gears is exposed in the browser
// in the future, but we will always support the google.gears.factory object.
//
// Circumvent this file at your own risk!

if (typeof google == 'undefined') {
  var google = {};
}

if (typeof google.gears == 'undefined') {
  google.gears = {};
}

if (typeof google.gears.factory == 'undefined') {
  google.gears.factory = (function() {
    // Firefox
    if (typeof GearsFactory != 'undefined') {
      return new GearsFactory();
    }

    // IE
    try {
      return new ActiveXObject('Gears.Factory');
    } catch (e) {}

    // Safari
    if (navigator.mimeTypes["application/x-googlegears"]) {
      var factory = document.createElement("object");
      factory.style.display = "none";
      factory.width = "0";
      factory.height = "0";
      factory.type = "application/x-googlegears";
      document.documentElement.appendChild(factory);
      return factory;
    }

    return null;
  })();
}
