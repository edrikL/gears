// The online version
function createManagedStore() {
  try {
    var localServer = google.gears.factory.create('beta.localserver', '1.0');
  } catch (ex) {
    setError('Could not create local server: ' + ex.message);
    return;
  }
  var store = localServer.createManagedStore(STORE_NAME);
  store.manifestUrl = 'manifest_v1.json';
  store.checkForUpdate();

  var timerId = window.setInterval(function() {
    // When the currentVersion property has a value, all of the resources
    // listed in the manifest file for that version are captured. There is
    // an open bug to surface this state change as an event.
    if (store.currentVersion) {
      window.clearInterval(timerId);
      textOut('Complete, press reload to see the locally served version ' +
              store.currentVersion);
    }
  }, 500);
}
