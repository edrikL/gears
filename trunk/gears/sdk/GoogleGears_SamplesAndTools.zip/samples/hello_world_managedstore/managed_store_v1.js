// The offline version 1
function updateManagedStore() {
  try {
    var localServer = google.gears.factory.create('beta.localserver', '1.0');
  } catch (ex) {
    setError('Could not create local server: ' + ex.message);
    return;
  }
  var store = localServer.openManagedStore(STORE_NAME);
  store.manifestUrl = 'manifest_v2.json';
  store.checkForUpdate();

  var timerId = window.setInterval(function() {
    // There is an open bug to surface this state change as an event.
    if (store.currentVersion != 'v1') {
      window.clearInterval(timerId);
      textOut('Complete, press reload to load version ' + store.currentVersion);
    }
  }, 500);
}
