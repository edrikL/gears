// The online version
function createManagedStore() {
  var localServer =
      google.scour.factory.create('com.google.beta.localserver', '1.0');
  var store = localServer.createManagedStore(STORE_NAME);
  store.manifestUrl = 'manifest_v1.json';
  store.checkForUpdate();
  
  var timerId = window.setInterval(function() {
    // When the currentVersion property has a value, all of the resources
    // listed in the manifest file for that version are captured. There is
    // an open bug to surface this state change as an event.
    if (store.currentVersion) {
      window.clearInterval(timerId);
      textOut('Complete, press reload to see the locally served version '
              + store.currentVersion);
    }
  }, 500);  
}

// The offline version 1
function updateManagedStore() {
  var localServer =
      google.scour.factory.create('com.google.beta.localserver', '1.0');
  var store = localServer.openManagedStore(STORE_NAME);
  store.manifestUrl = 'manifest_v2.json';
  store.checkForUpdate();
  
  var timerId = window.setInterval(function() {
    // There is an open bug to surface this state change as an event.  
    if (store.currentVersion != 'v1') {
      window.clearInterval(timerId);
      textOut('Complete, press reload to load version ' + store.currentVersion);
    }
  }, 500);
}

// The offline version 2
function removeManagedStore() {
  var localServer =
      google.scour.factory.create('com.google.beta.localserver', '1.0');
  localServer.removeManagedStore(STORE_NAME);
  textOut('Complete, press reload to see the online version again');
}

