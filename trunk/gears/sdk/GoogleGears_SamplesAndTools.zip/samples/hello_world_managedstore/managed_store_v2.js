// The offline version 2
function removeManagedStore() {
  try {
    var localServer = google.gears.factory.create('beta.localserver', '1.0');
  } catch (ex) {
    setError('Could not create local server: ' + ex.message);
    return;
  }
  localServer.removeManagedStore(STORE_NAME);
  textOut('Complete, press reload to see the online version again');
}
