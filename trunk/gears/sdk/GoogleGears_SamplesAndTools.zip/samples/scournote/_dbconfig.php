<?
// Customize this file to point to the database where db.sql has been setup.

$DBI_DATABASE="";
$DBI_USERNAME="";
$DBI_PASSWORD="";
$DBI_HOST="";
?>
