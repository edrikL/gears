// probably more stuff like bind() should go in here, but meh.

function listen(elm, ev, fn) {
  if (elm.addEventListener) {
    elm.addEventListener(ev, fn, false);
  } else {
    elm.attachEvent('on' + ev, fn);
  }
}

if (typeof console == 'undefined') {
  var console = {
    log: function() {},
    warn: function() {}
  };
 }

