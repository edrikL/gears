<?
require("_database.php");
require("_functions.php");
require("_layout.php");

validateUserCookie(true /* redirect if invalid */);
?>
<html>
<title>ScourNote</title>
<head>
<style type="text/css">
<? include("_style_base.php"); ?>

body {
  margin:0;
  overflow:hidden;
}

textarea {
  position:absolute; 
  overflow:auto; 
  left:2px; 
  top:1em; 
  right:2px; 
  bottom:1em; 
  margin-top:8px; 
  margin-bottom:2px; 
  border:1px solid #ccc;
}

iframe {
  height:200px;
}

#setup-offline a {
  color:red!important;
  font-weight:bold!important;
}

#status {
  position:absolute;
  bottom:0px;
  left:2px;
}

#contact {
  position:absolute;
  bottom:0px;
  right:2px;
}
</style>

<!--[if IE]>
<style type="text/css">
/*
  IE specific styles: override the definition of the elements to make them
  stretch right on IE's broken layout engine
*/
textarea {
  position:static;
  margin-top:1px;
  margin-left:2px;
  width:expression(document.body.offsetWidth - 6);
  height:expression(document.body.offsetHeight - 
		      (document.getElementById("status") ? 
                       document.getElementById("status").offsetHeight : 0) -
		      this.offsetTop - 5);
}

iframe {
  height:expression(document.body.offsetHeight - this.offsetTop);
}
</style>
<![endif]-->

</head>
<body onload="init()">

<? masthead(); ?>

<textarea></textarea>

<div id="status" class="green">Ready.</div>
<div id="contact">
  <a href="mailto:scour-eng@google.com?subject=ScourNote">Contact</a>
</div>

<script type="text/javascript" src="base.js"></script>
<script type="text/javascript" src="cookies.js"></script>
<script type="text/javascript" src="xhr.js"></script>
<script type="text/javascript" src="scour.js"></script>
<script type="text/javascript" src="datastore.js"></script>
<script type="text/javascript" src="note.js"></script>

</body>
</html>
