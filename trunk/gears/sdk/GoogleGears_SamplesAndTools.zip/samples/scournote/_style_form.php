input, select {
  border:1px solid grey;
  margin-top:2px;
  width:190px;
}

.error {
  font-weight:bold;
  color:red;
}

.ok {
  color:#090;
}
