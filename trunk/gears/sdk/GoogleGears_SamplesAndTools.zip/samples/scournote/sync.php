<?
require("_functions.php");
require("_database.php");

$id = validateUserCookie();
$version = $_GET['version'];

if (!$version) {
  die('Where is $version?');
}

$id = db_escape($id);
$version = db_escape($version);
$rslt = firstRow(db_query_get("select version, content from user where " .
                              "id = '$id' and version > '$version'"));

if ($rslt) {
  $version = $rslt['version'];
  $content = $rslt['content'];

  print "$version\n$content";
} 
// else serve an empty 200 OK response, which means the client is up to date.
?>