// The 'name' of the managed store used by this demo
var STORE_NAME = "helloworld-managedstore";

function canDemo() {
  if (!window.google || !google.gears) {
    setError('Gears is not installed');
    return false;
  } else if (location.protocol.indexOf("http") != 0) {
    setError('This sample must be hosted on an HTTP server');
    return false;
  } else {
    return true;
  }
}

// The remaining functions are unrelated to Gears APIs

function httpGet(url) {
  if (!checkProtocol()) {
    return 'This sample must be hosted on an HTTP server';
  }
  if (window.XMLHttpRequest) {
    xmlhttp = new XMLHttpRequest();
  } else if (window.ActiveXObject) {
    xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
  }
  xmlhttp.open('GET', url, false);
  xmlhttp.send(null);
  return xmlhttp.responseText;
}

function showSourceFileInline(url, divId) {
  var source = httpGet(url);
  var html = '<pre>' + source + '</pre>';
  var div = document.getElementById(divId);
  div.innerHTML = html;
}

function textOut(s) {
  var elm = document.getElementById('textOut');
  while (elm.firstChild) {
    elm.removeChild(elm.firstChild);
  }
  elm.appendChild(document.createTextNode(s));
}
