body {
  margin:0;
}

body, td {
  font-family:helvetica, arial, sans-serif;
  font-size:11px;
}

p {
  margin-top:0;
  margin-bottom:1em;
}

a {
  color:#006;
}

a:visited {
 color:#006;
}

a:hover {
  background:#def;
}

#masthead {
  background:#f2f3f4; 
}

#masthead td {
  padding:2px 3px;
  font-size:12px;
}

#masthead b {
  color:#090;
}

.green {
  color:#090;
}

.orange {
  color:#FF7735;
}

.red {
  color:#F00;
}

