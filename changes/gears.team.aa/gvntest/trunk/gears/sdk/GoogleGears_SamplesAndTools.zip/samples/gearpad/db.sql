/**
 * Schema for Gearpad. After creating a blank database called 'gearpad',
 * run with something like:
 *
 * mysql -u myuser -p gearpad < db.sql
 *
 * WATCH OUT! THIS IS A VERY COMPLEX SCHEMA!!!
 */

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `version` int(11) NOT NULL,
  `updated` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

