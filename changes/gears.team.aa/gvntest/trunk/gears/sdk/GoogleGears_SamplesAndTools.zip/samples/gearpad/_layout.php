<? function masthead($subtitle = '') { ?>
<table id="masthead" width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
  <td align="left">
    <b>Gearpad</b>
    <? if ($subtitle) print "/ <b>$subtitle</b>"; ?>
  </td>
  <td id="login-bar" align="right" style="display:none">
    Logged in as <b id="logged-in-as"></b> 
    | <a href="#" onclick="logout();">logout</a></span> 
    <span id="setup-offline">| 
        <a href="#" onclick="setupOffline(event); return false;">
            Set Up Offline Access!</a></span>
  </td>
</tr>
</table>
<? } ?>