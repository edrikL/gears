// JavaScript for the main ui of Gearpad.
// Watch the textarea for changes, and when they occur send them off to
// DataStore.

var t = document.getElementsByTagName("textarea")[0];
var lastSavedVal = t.value;
var saveTimeout = 500; // 500 milliseconds of quiet before autosave
var idleTimeout = 5000; // 5 seconds idle sync
var gears;
var timerId;
var snapshot;
var store;

function init() {
  gears = new Gears();
  store = new DataStore(onsync);

  document.getElementById("login-bar").style.display = "";
  document.getElementById("logged-in-as").appendChild(
      document.createTextNode(store.email));

  if (store.localMode) {
    document.getElementById("setup-offline").style.display = "none";
  }

  listen(t, "keyup", keypress);
  listen(t, "keypress", keypress);
  //listen(window, "focus", focused);

  sync();
}

function keypress() {
  scheduleSync(saveTimeout);
}

function focused(e) {
  if (!e) e = window.event;
  if (e.stopPropagation) e.stopPropagation();

  sync();

  return false;
}

function scheduleSync(timeout) {
  cancelSchedule();
  timerId = window.setTimeout(sync, timeout);
}

function cancelSchedule() {
  if (timerId) {
    timerId = window.clearTimeout(timerId);
  }
}

function sync() {
  cancelSchedule();
  snapshot = t.value;

  if (t.value != lastSavedVal) {
    setStatus("Saving...", "orange");
    store.sync(snapshot);
  } else {
    setStatus("Syncing...", "orange");
    store.sync(null);
  }
}

function onsync(newContent) {
  // If the textbox has changed since the sync was sent, then the result is
  // invalid and the sync must be redone. This can happen since syncs from 
  // typing are delayed and server requests are asynchronous.
  if (snapshot != t.value) {
    sync();
    return;
  }

  if (newContent !== null) {
    t.value = newContent;
  }

  lastSavedVal = t.value;

  if (store.online) {
    setStatus('Online.', 'green');
  } else {
    setStatus('Offline.', 'orange');
  }

  scheduleSync(idleTimeout);
}

function setStatus(msg, color) {
  var elm = document.getElementById("status")
  elm.className = color;
  elm.innerHTML = msg;
}

function logout() {
  eraseCookie("c");
  location.href = "login.php";
}

function setupOffline() {
  if (!gears.hasGears) {
    location.href = 'getgears.php';
    return;
  }

  if (!gears.hasDb) {
    gears.createDatabase();
  }

  gears.addUser(store.userId,
                unescape(readCookie('c')),
                t.value,
                store.version);

  if (!gears.isCaptured) {
    gears.capture();
  } else {
    location.reload();
  }
}

function promptToOverrideConflict() {
  return confirm(
     'The note has been changed on another computer. Override changes?');
}
