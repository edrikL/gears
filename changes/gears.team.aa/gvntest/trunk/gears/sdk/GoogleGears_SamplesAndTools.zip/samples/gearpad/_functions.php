<?
// Utility functions used by rest of Gearpad php pages.


//==============================================================================
// Custom error handling.
//==============================================================================
// Since we're using AJAX, the status code matter to us.
// Usually PHP just returns 200 for everything since it isn't buffering, it 
// too late to change the status by the time it figures out there's a problem.
//
// So, we need to buffer the output and errors we encounter and set the right
// status code if we get an error.
//==============================================================================
function handleError($code, $desc, $file, $line) {
  if ($code == E_NOTICE) {
    return;
  }

  ob_clean();
  header("Content-type: text/plain");
  header("HTTP/1.1 500 Internal Server Error");
  print("ERROR: $code $desc. $file:$line");
  exit();
}

ob_start();
set_error_handler("handleError");



//==============================================================================
// Cookie handling.
//==============================================================================
// This cookie policy is not secure and just for demo. In a real application
// you'd want to encrypt the create time with the cookie and invalidate old
// cookies on the server.
//==============================================================================

$SITE_SECRET = "gears-demo";

function setUserCookie($userid, $email) {
  global $SITE_SECRET;

  $hash = md5($userid.'-'.$SITE_SECRET);
  $val = $userid.'-'.$hash.'-'.$email;

  // store the cookie for 30 days
  setcookie('c', $val, time() + 60*60*24*30, '/');
}

function validateUserCookie($redirectIfInvalid = false) {
  global $SITE_SECRET;

  $raw = $_COOKIE['c'];

  if (!$raw) {
    handleInvalidUserCookie($redirectIfInvalid);
  }

  $vals = explode('-', $raw);

  if (count($vals) != 3) {
    return false;
  }

  $userid = $vals[0];
  $hash = $vals[1];

  if ($hash != md5($userid.'-'.$SITE_SECRET)) {
    handleInvalidUserCookie($redirectIfInvalid);
  }

  return $userid;
}

function handleInvalidUserCookie($redirectIfInvalid) {
  if ($redirectIfInvalid) {
    header('Location: login.php');
  } else {
    header("HTTP/1.1 403 Forbidden");
  }
  exit();
}


//==============================================================================
// Account management
//==============================================================================

function updateNote($id, $version, $content) {
  $id = db_escape($id);
  $version = db_escape($version);
  $content = db_escape($content);

  $rslt = db_query_set(
      "update user set content='$content', version=version+1 
       where id = '$id' and version = '$version'");
  $num_rows = mysql_affected_rows();
  
  if ($num_rows == 0) {
    return firstRow(db_query_get(
        "select version, content from user where id = '$id'"));
  }

  return false;
}

function createAccount($email, $password) {
  $email = db_escape($email);
  $password = crypt(db_escape($password));
  $userid = db_query_set(
      "insert into user (email, password, version, content) 
       values ('$email', '$password', 1, 'Hello, world!')");

  // $email was already in use
  if (!$userid) {
    return false;
  }

  setUserCookie($userid, $email);
  return $userid;
}

function login($email, $password) {
  $email = db_escape($email);

  $rslt = firstRow(db_query_get("select id, password from user
                                 where email = '$email'"));

  if (!$rslt) {
    return 'email';
  }

  if ($rslt['password'] != crypt($password, $rslt['password'])) {
    return 'password';
  }

  setUserCookie($rslt['id'], $email);
  return $rslt['id'];
}

function mailPassword($email) {
  global $SITE_SECRET;

  $token = crypt($email . $SITE_SECRET);
  $token = str_replace(array('.','/'), array('-','_'), $token);

  $path = explode('/', $_SERVER['SCRIPT_NAME']);
  array_pop($path);
  array_push($path, 'resetpass.php');

  mail($email, 
       'Account reset for Gearpad',
       "Click below to reset your account:\n\n"
       . 'http://' . $_SERVER['SERVER_NAME'] . implode('/', $path) .
       '?email=' . urlencode($email) . '&token=' . $token . "\n",
       'From: Gearpad <gearpad@example.com>\r\n');

  return true;
}

function resetPassword($email, $token, $newpass) {
  global $SITE_SECRET;

  $token = str_replace(array('-','_'), array('.','/'), $token);
  $check = crypt($email . $SITE_SECRET, $token);

  if ($check != $token) {
    return false;
  }

  $newpass = db_escape($newpass);
  $newpass = crypt($newpass);

  db_query_set("update user set password = '$newpass' where email = '$email'");
  $rslt = firstRow(db_query_get("select id from user where email = '$email'"));
  setUserCookie($rslt['id'], $email);

  return true;
}
?>
