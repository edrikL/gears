<html>
<title>Gearpad</title>
<head>
<style type="text/css">
 <? include("_layout.php"); ?>
<? include("_style_base.php"); ?>
</style>
</head>

<body>
<? masthead("enable offline access"); ?>

<div id='main' style='margin:1em; font-size:1.2em;'>
<p>Offline access requires <b><a
    href='http://gears.google.com/'
    target='_blank'>Google Gears</a></b>. Go install it, then come back here
    to finish setting up offline access.
</div>

</body>
</html>
