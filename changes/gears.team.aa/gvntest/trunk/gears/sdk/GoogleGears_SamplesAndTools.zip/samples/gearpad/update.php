<?
require("_database.php");
require("_functions.php");

$id = validateUserCookie();
$version = $_GET['version'];
$content = file_get_contents('php://input');

$conflict = updateNote($id, $version, $content);
if ($conflict) {
  $version = $conflict['version'];
  $existing = $conflict['content'];
 } else {
  $version += 1;
}

if (!$conflict) {
  print "$version";
} else {
  print "$version\n$existing";
}
?>