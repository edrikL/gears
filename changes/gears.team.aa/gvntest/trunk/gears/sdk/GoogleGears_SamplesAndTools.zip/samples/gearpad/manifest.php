<?
require('_functions.php');

header('Content-type: text/plain');

$version = 0;
$dir = dirname($_SERVER['SCRIPT_FILENAME']);
$handle = opendir($dir);

while (false !== ($file = readdir($handle))) {
  if (file_exists("$dir/$file")) {
    $v = filemtime("$dir/$file");
    if ($v > $version) {
      $version = $v;
    }
  }
}

$files = array(
  '.',
  'accelimation.js',
  'base.js',
  'cookies.js',
  'datastore.js',
  'labels.js',
  'login.php',
  'note.js',
  'utils.js',
  'xhr.js'
  );

$entries = array();
foreach ($files as $file) {
  array_push($entries, "    {\"url\": \"$file\"}");
}
?>
{
  "betaManifestVersion": 1,
  "version": "<?= $version ?>",
  "entries": [
<?= implode(",\n", $entries); ?>

  ]
}
